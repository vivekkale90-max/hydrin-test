module.exports = { content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'], theme: { extend: { colors: { hydrinAqua: '#66d9ff', hydrinSilver: '#bfc6c9', hydrinBlack: '#0b0b0b' } } }, plugins: [], }
