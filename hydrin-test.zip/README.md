Hydrin Test - Vite React project (ready for Netlify)

How to use:
1. Extract this folder.
2. In the project root, run:
   npm install
   npm run build
3. Push to your GitHub repo (main branch).
4. Netlify build settings:
   - Build command: npm run build
   - Publish directory: dist

Notes:
- This is a test/demo project with placeholder assets.
- Replace src/assets/bottle.png with your real bottle image.
